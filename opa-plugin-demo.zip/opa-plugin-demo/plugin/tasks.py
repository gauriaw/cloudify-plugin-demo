# you can use the decorators that gives the ability
# to mark the task as resumable or not
from cloudify.decorators import operation
# you can use the exeption logic to mark the operation final status
# [ as it will affect the workflow execution] you can raise according
# to your logic could be `RecoverableError` if you want you code to do retries
# and wait for a certian period of time or `NonRecoverableError`
# which means mark this operation as failure and stop the flow right there
# unless you set ignore_failure flag as true on the workflow trigger
from cloudify.exceptions import NonRecoverableError

# 'ctx' is always passed as a keyword argument to operations, so
# your operation implementation must either specify it in the arguments
# list, or accept '**kwargs'. Both are shown here.


@operation
def my_task(ctx, **kwargs):
    # getting some values from passed properties
    hello = ctx.node.properties.get('demo_config.hello', '')

    # you can use the cloudify context logger
    ctx.logger.info('Got these valuesfor hello {0}'.format(hello))

    # you can put here what is the actual task defintion
    # that you want to implement
    if hello == "World":
        # do something useful with that properties values
        ctx.instance.runtime_properties['allow'] = \
                'True'
    else:
        ctx.instance.runtime_properties['allow'] = \
            'False'
        ctx.instance.runtime_properties['failure_reason'] = \
            'invalid or empty inputs'
        # or raise an error that will stop the workflow due to failure
        raise NonRecoverableError('Invalid inputs were passed '
                                  'to this operation')
